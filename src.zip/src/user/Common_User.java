/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package user;

/**
 *
 * @author thao.tran
 */
public class Common_User extends User{
    protected String name;

    public Common_User(String name, Account account){
        this.name=name;
        this.account=account;
}

//    public Double getId() {
//        return id;
//    }
//
//    public void setId(Double id) {
//        this.id = id;
//    }

    public Account getAcount() {
        return account;
    }

    public void setAcount(Account acount) {
        this.account = acount;
    }
    public void checkbalance(){
    
    } 
    public void withdrawCash(double money){
    
    }
    public void transferFunds(double money, double reAccountname){
    
    }
    public String printBill(){
        return null;    
    }
    public String getName(){
        return null;
    }

    public void setName(String name){
        this.name=name;
    }

}