/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package user;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * 
 */
public class Show {
    public static void showMenu(int id) {
        if(id == 1){
            System.out.println("************************************************");
            System.out.println("*         Emulator ATM application             *");
            System.out.println("************************************************");
            System.out.println("=======================MENU=====================");
            System.out.println("Choose, please!: ");
            System.out.println("1.Withdraw Cash");
            System.out.println("2.Transfer Funds");
            System.out.println("3.Check Balance");
            System.out.println("4.Change password");
            System.out.println("5.Print bill");
            System.out.println("6.Cancle"); 
            System.out.println("Choose: "); 
        }
        else if(id == 0){
            System.out.println("************************************************");
            System.out.println("*         Emulator ATM application             *");
            System.out.println("************************************************");
            System.out.println("=======================MENU=====================");
            System.out.println("Choose, please: ");
            System.out.println("1.Add balance for ATM");
            System.out.println("2.Add balance for USER");
            System.out.println("3.Create user account"); 
            System.out.println("4.Reset user password"); 
            System.out.println("Choose: "); 
        }
    }
    public void main0() {
    Scanner nhap = new Scanner( System.in);   
    
    int a;
        a=nhap.nextInt();
	switch(a){
	case 1:
	System.out.println("___________________WITHDRAW CASH___________________");
        break;
            
	case 2:
  	System.out.println("___________________RANSFER FUNDS___________________");
	break;
            
	case 3:
	System.out.println("___________________CHECK BALANCE___________________");
	break;
            
	case 4:
	System.out.println("___________________CHANGE PASSWORD_________________");
        break;
            
	case 5:
	System.out.println("___________________PRINT BILL______________________");
	break;
            
	case 6:
        System.out.println("THANK YOU FOR SERVICE USING");
        break;
}
}
    
    public void main1() {
    Scanner nhap = new Scanner( System.in);   
    
    int a;
        a=nhap.nextInt();
	switch(a){
        case 1:
	System.out.println("________________ADD BALANCE FOR ATM________________");
        break;
            
	case 2:
	System.out.println("________________ADD BALANCE FOR USER_______________");
        break;
            
        case 3:
	System.out.println("________________CREATE USER ACCOUNT________________");
        break;
            
        case 4:
	System.out.println("________________RESET USER PASSWORD________________");
        break;
            
        case 5:
	System.out.println("THANK YOU FOR SERVICE USING");
        break;
        }
    }
    public void showLogin() {
    System.out.println("************************************************");
    System.out.println("*         Emulator ATM application             *");
    System.out.println("************************************************");
    System.out.println("===============WELCOME YOU TO ATM================");
    System.out.println("Please login to continue: ");
    System.out.println("1.LOGIN ");
    System.out.println("2.CANCLE ");
    }
    public static void loginScreen() {
        Account admin1 = new Account("admin","admin");
        Admin admin = new Admin(admin1);

        Account account1 = new Account("trungnguyen","trung123",100000000,1,"ABC");
        Account account2 = new Account("thaotran","thao123",1000000,2,"Vietcombank");

        Loyalty_User user = new Loyalty_User("Nguyen Tan Trung",account1);
        Common_User user1 = new Loyalty_User("Tran Thi Thao",account2);
        
        ArrayList<Account> listAccount = new ArrayList<Account>();
        listAccount.add(admin1);
        listAccount.add(account1);
        listAccount.add(account2);
    Scanner scan = new Scanner( System.in);   
    String account;
    String password;
    int a;
        a=scan.nextInt();
        scan.nextLine();
	switch(a){
	case 1:
	System.out.println("___________________LOG IN___________________");
	System.out.println("Account: ");
        account = scan.nextLine();
        System.out.println("Password: ");
        password = scan.nextLine();
        User.login(account, password, listAccount);
        break;
        
        case 2:
	System.out.println("THANK YOU FOR USING SERVICE");
        break;
        }
    }
    public static void main(String[] args) {
    Show show = new Show();
    show.showLogin();
    show.loginScreen();
    
}
}
