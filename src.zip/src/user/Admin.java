/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package user;

/**
 *
 * @author thao.tran
 */
public class Admin extends User{

public Admin(Account account) {
    this.account = account;
}

public void addBalanceAtm(Double money, Integer idATM){

}
public void createUser(String name, Integer id, Account account){

}
public void addBalanceUser(Double money, Integer id){

}
public void changeUserPassword(Integer id){

}

}
