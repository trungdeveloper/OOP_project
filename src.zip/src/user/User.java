/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package user;

import java.util.ArrayList;

/**
 *
 * @author trung.nguyen
 */
public abstract class User {
    protected Account account;
    
    protected static void login(String user, String password, ArrayList<Account> list){
        int ok = 0;
        for (Account list1 : list) {
            if (user.equals(list1.getAccountName()) && password.equals(list1.getPassword())) {
                Show.showMenu(list1.getType());
                ok = 1;
                break;
            }
        }
        if(ok == 0){
            System.out.println("Wrong Account name or Password!!! Please check again");
            Show.loginScreen();
        }
    }
    
    protected void logout(){
        for(int i = 0; i < 10; i++)
            System.out.println("/n");
    }
}
